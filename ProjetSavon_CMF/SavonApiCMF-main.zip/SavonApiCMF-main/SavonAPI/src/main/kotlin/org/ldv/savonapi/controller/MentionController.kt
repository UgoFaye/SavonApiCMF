package org.ldv.savonapi.controller

class MentionController {
}