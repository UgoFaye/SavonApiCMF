package org.ldv.savonapi.dto

class MentionDTO {
}