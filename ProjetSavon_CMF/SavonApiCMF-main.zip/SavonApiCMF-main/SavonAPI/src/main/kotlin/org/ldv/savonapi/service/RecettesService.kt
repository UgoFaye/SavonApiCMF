package org.ldv.savonapi.service

class RecettesService {
}