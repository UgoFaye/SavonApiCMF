package org.ldv.savonapi.dto

class CaracteristiqueDTO {
}