package org.ldv.savonapi.dto

class RecettesDTO {
}