package org.ldv.savonapi.dto

class QuantiteDTO {
}